#pragma once

#define HTTP_SERVER "49.12.233.88"
#define HTTP_PORT 80

#define TFTP_SERVER "49.12.233.88"
